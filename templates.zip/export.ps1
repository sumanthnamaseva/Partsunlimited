﻿$currentPath = pwd
$AzureDevOpsPAT = "65t7nzkw5mtdxcaxe4gfxiqmdj3dxaiepz22g2onufkfcrlt2uiq"
$OrganizationName = "ADSP-Org-A04"
$downloadPath = "C:\Users\320124857\Downloads\customtemplates"
$csvfilename = "custom_templates.csv"

$AzureDevOpsAuthenicationHeader = @{
 Accept = 'application/json;api-version=6.0-preview.1';
Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($AzureDevOpsPAT)")) }

cd $downloadPath 
$get_templates_uri = "https://dev.azure.com/$($OrganizationName)/_apis/process/processes?api-version=6.0-preview.1"

$response = Invoke-RestMethod -Uri $get_templates_uri -Method get -Headers $AzureDevOpsAuthenicationHeader
$process_template_ids = @()
$process_template_names= @()
foreach($process_template in $response.value) {
    if ($process_template.type -eq "custom") {
        $process_template_ids += $process_template.id
        $process_template_names += $process_template.name 
    }
}
$iterator = 0
New-Item -Path $downloadPath -Name $csvfilename -ItemType File -Force
cd $downloadpath

Add-Content $csvfilename "PROCESS_NAME,PROCESS_ID"
foreach($process_template_name in $process_template_names) {
    if($process_template_name -ne "Scrum" -and $process_template_name -ne "Agile" -and $process_template_name -ne "Basic" -and $process_template_name -ne "CMMI") {
        $process_template_id = $process_template_ids[$iterator]
        "{0},{1}" -f $process_template_name,$process_template_id | Add-Content -path .\$csvfilename
        $iterator = $iterator + 1
    }
}

Import-Csv -Path .\$csvfilename -Delimiter "," |ForEach-Object {
        $template_id = $_.PROCESS_ID
        $template_name = $_.PROCESS_NAME
        $export_uri = "https://dev.azure.com/$($OrganizationName)/_apis/work/processadmin/processes/export/$($template_id)?api-version=6.0-preview.1"
        Invoke-RestMethod -Uri $export_uri -Method get -Headers $AzureDevOpsAuthenicationHeader -OutFile $template_name".zip"
}
cd $currentPath