﻿param ($name)
$currentPath = pwd
$AzureDevOpsPAT = "65t7nzkw5mtdxcaxe4gfxiqmdj3dxaiepz22g2onufkfcrlt2uiq"
$OrganizationName = "ADSP-Org-A04"
$downloadPath = "C:\Users\320124857\Downloads\customtemplates"
$csvfilename = "custom_templates.csv"

$AzureDevOpsAuthenicationHeader = @{
 Accept = 'application/json;api-version=6.0-preview.1';
Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($AzureDevOpsPAT)")) }

cd $downloadPath

if($PSBoundParameters.ContainsKey('name')) {
    $zipfilePath = Get-ChildItem $name".zip"
    $Uri = "https://dev.azure.com/$($OrganizationName)/_apis/work/processadmin/processes/import?ignoreWarnings=False'&'replaceExistingTemplate=True'&'api-version=6.0-preview.1"
    Invoke-RestMethod -Uri $uri -Headers $AzureDevOpsAuthenicationHeader -UserAgent $userAgent -Method POST -InFile $zipfilePath.FullName -ContentType "application/octet-stream"
}
else {  
    Import-Csv -Path .\$csvfilename -Delimiter "," |ForEach-Object {
        $template_name = $_.PROCESS_NAME       
        Get-ChildItem $template_name".zip" | ForEach-Object {
            $zipfilePath = $_.FullName
            $Uri = "https://dev.azure.com/$($OrganizationName)/_apis/work/processadmin/processes/import?ignoreWarnings=False'&'replaceExistingTemplate=True'&'api-version=6.0-preview.1"
            Invoke-RestMethod -Uri $uri -Headers $AzureDevOpsAuthenicationHeader -UserAgent $userAgent -Method POST -InFile $zipfilePath -ContentType "application/octet-stream"
        }
    }
}
cd $currentPath